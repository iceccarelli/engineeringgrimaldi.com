# Grimaldi Engineering — Companies Hub Visual Assets
## For engineeringgrimaldi.com (Companies Hub)

These 10 professional images support the new companies hub for **Time to Power (Gridforge)** and **NeuralBridge**.  
They are designed for the homepage, company overview sections, and supporting pages.  
Use them to replace outdated cluster/palletizer visuals.

**Upload location recommendation:**  
`/public/images/companies/` in the engineeringgrimaldi.com repo root (or equivalent Next.js public folder).

All images are landscape (approx. 1176×784), dark technical aesthetic, high-quality for hero, card, and section use.

---

### Company One-Sentence Value Props (for homepage)

**Time to Power (Gridforge)**  
Power-capacity intelligence for existing AI data-centre halls: we identify the binding electrical or thermal constraint, what unlocks more useful compute, the cost, the lead time, and the evidence class behind every number.

**NeuralBridge**  
Industrial Autonomous Assurance: tamper-evident, hash-chained records that keep safety verifications matched to the actual software and configuration of machines — so compliance evidence stays current when firmware, advisories, or systems change.

**Stage (honest):** Pilot-stage · founder-led · Frankfurt / Toronto

**Direct links:**  
- https://timetopower.ai  
- https://neuralbridge.io

---

### Image Inventory + Placement + SEO/AEO

| # | Filename | Primary Use | Alt Text (SEO) | Recommended Placement | AEO / Content Notes |
|---|----------|-------------|----------------|-----------------------|---------------------|
| 01 | `01-time-to-power-data-center-hall.jpg` | Hero / Time to Power visual | AI data center hall with power flow overlays showing capacity constraints | Homepage hero or Time to Power section top | Supports “power is the bottleneck” narrative. Use with value prop above. |
| 02 | `02-gridforge-capacity-envelope.jpg` | Technical diagram | GridForge capacity envelope diagram showing electrical and thermal binding constraints | Time to Power “How it works” or evidence section | Ideal for explaining the engine. Pair with “no equipment sold” language. |
| 03 | `03-time-to-power-interconnection-path.jpg` | Conceptual path | Time to power visualization: interconnection queue path to energized AI capacity | Time to Power overview or siting/intelligence mention | Good for “time to power” keyword. Links naturally to product site. |
| 04 | `04-neuralbridge-machine-safety-verification.jpg` | NeuralBridge hero | Industrial machine control panel with safety verification and evidence overlays | NeuralBridge section top | Emphasizes machine software that affects safety. |
| 05 | `05-neuralbridge-hash-chained-evidence.jpg` | Evidence concept | Hash-chained evidence ledger for industrial autonomous assurance | NeuralBridge “What it does” or assurance explanation | Strong for “tamper-evident” and “hash-chained” language. |
| 06 | `06-neuralbridge-industrial-assurance-floor.jpg` | Facility context | Industrial floor with digital twin overlays for machine configuration integrity | NeuralBridge supporting visual or about section | Shows real-world application without claiming specific customers. |
| 07 | `07-grimaldi-engineering-two-companies.jpg` | Dual companies | Grimaldi Engineering: Time to Power power-capacity intelligence and NeuralBridge industrial assurance | Homepage main visual or “Two companies” section | Best single image for the hub. Centered geometric mark unifies both. |
| 08 | `08-physics-informed-power-systems.jpg` | Technical foundation | Physics-informed digital twin of power systems and grid infrastructure | About or technical credibility section | Ties to founder background (grids, physics-informed). |
| 09 | `09-founder-engineering-workspace.jpg` | About / operator | Founder-led engineering workspace with capacity models and assurance dashboards | Short about section or footer area | Supports “founder-led, pilot-stage” honesty. Frankfurt skyline subtle. |
| 10 | `10-companies-hub-status-surface.jpg` | Status / inquiry UI | Clean companies hub status surface showing Time to Power and NeuralBridge | Inquiry or status section | Can illustrate the hub itself. Avoid implying live revenue numbers. |

---

### Suggested Homepage Structure (content + images)

1. **Hero**  
   Image: `07-grimaldi-engineering-two-companies.jpg` or `01-...`  
   Headline: Grimaldi Engineering  
   Sub: Two companies. Power-capacity intelligence and industrial autonomous assurance.  
   Stage line: Pilot-stage · founder-led  
   Links: timetopower.ai · neuralbridge.io

2. **Companies Overview**  
   Two cards.  
   - Time to Power card → images 01 / 02 / 03  
   - NeuralBridge card → images 04 / 05 / 06  
   Each with one-sentence value prop + “Learn more” external link.

3. **Honest Status**  
   Image: `10-companies-hub-status-surface.jpg` or `09-...`  
   Text: Pilot-stage. No public customer counts or revenue figures published. Evidence and status live on the product sites.

4. **Inquiry Paths**  
   Separate or tagged forms/links for each company (or simple mailto + product site CTAs).

5. **Short About**  
   Image: `08-physics-informed-power-systems.jpg` or `09-...`  
   Bio: Vincenzo Grimaldi — founder of Gridforge (Time to Power) and NeuralBridge. ITk Fachspezialist at DB InfraGO AG (traction HV digitisation). M.Sc. RWTH Aachen Electrical Power Engineering. Frankfurt / Toronto.

---

### SEO / AEO Recommendations

- File names are already keyword-rich and descriptive.
- Use the provided alt texts exactly or with minor natural adjustments.
- Surround images with the value props and stage language so search engines and answer engines see consistent, honest signals.
- Prefer external links to the product sites rather than duplicating full product content here.
- Keep “pilot-stage / founder-led” visible so the hub does not overclaim.
- Open Graph / Twitter cards: use image 07 or 01 as the primary social image.

---

### Kill List (do not reintroduce)

- Three-cluster language  
- Palletizer / Physical AI cluster  
- Empty KPI boards / weekly CEO reports  
- Old GridOS / DERIM as primary  
- Any implication of a group operating system

These assets are ready for the companies hub. Product sites remain primary.  
Upload the folder or individual files into the public directory of the engineeringgrimaldi.com repository.
