# engineeringgrimaldi.com — Critical & High-Prospect Visual Assets
## Additional 10 images for the companies hub (Gridforge / Time to Power + NeuralBridge)

These 10 images focus on **critical, cutting-edge aspects** of the two companies and the **near-term billion-dollar prospects** they address.

They are designed for the companies hub surface and support the product sites (timetopower.ai and neuralbridge.io) without contradicting them.

**Upload location recommendation:**  
`/public/images/critical/` or `/public/images/prospect/` in the engineeringgrimaldi.com repo.

All images are landscape (approx. 1176×784), dark technical professional aesthetic.

---

### Company Alignment

- **Time to Power / Gridforge**: power-capacity intelligence for AI data centers. Capacity envelopes, interconnection, binding constraints, time-to-power.  
- **NeuralBridge**: autonomous assurance. Hash-chained evidence binding safety verifications to machine software configurations.  
- Honest stage: founder-led / pilot. No invented revenue or customer numbers.

---

### Image Inventory + Placement + Aspect Explained

| # | Filename | Aspect Explained | Alt Text (SEO) | Recommended Placement | Prospect Note |
|---|----------|------------------|----------------|-----------------------|---------------|
| 01 | `01-time-to-power-capacity-intelligence.jpg` | Time to Power core | Time to Power capacity intelligence for AI data centers | Homepage hero or companies overview | Core problem and signal. |
| 02 | `02-gridforge-capacity-envelope.jpg` | Capacity envelope | GridForge capacity envelope of electrical and thermal limits | Time to Power section | Exact product framing. |
| 03 | `03-interconnection-siting-intelligence.jpg` | Interconnection & siting | Interconnection and siting intelligence for AI power capacity | Time to Power / overview | Queue and capacity as the bottleneck. |
| 04 | `04-neuralbridge-autonomous-assurance.jpg` | NeuralBridge core | NeuralBridge autonomous assurance with hash-chained safety evidence | NeuralBridge section | Evidence for safety-relevant software. |
| 05 | `05-physics-informed-data-center-power.jpg` | Physics-informed foundation | Physics-informed digital twin of data center power infrastructure | Technical foundation / about | Shared method across both companies. |
| 06 | `06-founder-pilot-workspace.jpg` | Current stage | Founder-led pilot engineering workspace | Short about or status | Honest stage language. |
| 07 | `07-ai-is-power-bound.jpg` | AI is power-bound | AI infrastructure constrained by electrical capacity | Overview or explainer | Why the work matters. |
| 08 | `08-industrial-safety-verification.jpg` | Industrial safety verification | Industrial safety verification for autonomous machines | NeuralBridge supporting visual | Compliance and evidence angle. |
| 09 | `09-two-companies-technical-foundation.jpg` | Two companies | Two companies sharing a technical foundation in power and assurance | Homepage dual companies section | Clean umbrella visual. |
| 10 | `10-power-capacity-billion-dollar-prospect.jpg` | Near-term scale | Power capacity as the critical path for AI data center expansion | Prospect or closing section | Illustrates the size of the constraint. |

---

### Suggested Placement on engineeringgrimaldi.com

- **Homepage hero / dual companies**: 09 or 01  
- **Time to Power section**: 01, 02, 03, 07, 10  
- **NeuralBridge section**: 04, 08  
- **Technical foundation / about**: 05  
- **Honest status / founder-led**: 06  
- **Prospect / why it matters**: 10 or 07  

Keep the product sites primary. This hub is the clean umbrella, status, and inquiry surface. Use these images to make the problems and methods visible without over-claiming.

---

### SEO / AEO Notes

- File names are company-aligned and descriptive.  
- Surround with language about power-capacity intelligence, time-to-power, capacity envelopes, autonomous assurance, and hash-chained evidence.  
- Link directly to timetopower.ai and neuralbridge.io.  
- Pair with the earlier companies hub assets for a complete visual system.  
- Honest stage language only.

These 10 images make the critical, high-value aspects of both companies visible on the hub.  
Upload into the public directory of the engineeringgrimaldi.com repository.
